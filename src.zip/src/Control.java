// Control.java
// View와 Model을 연결하는 Controller 파일

public class Control {

    // View 객체들
    private MainFrame mainFrame;
    private MainPanel mainPanel;
    private MenuPanel menuPanel;
    private OptionPanel optionPanel;
    private CartPanel cartPanel;
    private OrderCompletePanel orderCompletePanel;

    // Model 객체들
    private Cart cart;
    private Menu selectedMenu;

    // 생성자: Main에서 만든 View 객체와 Model 객체를 받아와 연결함
    public Control(
            MainFrame mainFrame,
            MainPanel mainPanel,
            MenuPanel menuPanel,
            OptionPanel optionPanel,
            CartPanel cartPanel,
            OrderCompletePanel orderCompletePanel,
            Cart cart
    ) {
        this.mainFrame = mainFrame;
        this.mainPanel = mainPanel;
        this.menuPanel = menuPanel;
        this.optionPanel = optionPanel;
        this.cartPanel = cartPanel;
        this.orderCompletePanel = orderCompletePanel;
        this.cart = cart;

        connectEvents();
    }

    // View의 버튼에 이벤트를 연결하는 메서드
    private void connectEvents() {

    mainPanel.getNextBtn().addActionListener(e -> {
        mainFrame.changePanel(menuPanel);
    });

    menuPanel.getVanillaRadio().addActionListener(e -> {
        selectedMenu = new Menu("vanilla", 3500);
    });

    menuPanel.getStrawberryRadio().addActionListener(e -> {
        selectedMenu = new Menu("strawberry", 3500);
    });

    menuPanel.getChocoRadio().addActionListener(e -> {
        selectedMenu = new Menu("choco", 3500);
    });

    menuPanel.getNextBtn().addActionListener(e -> {
        if (selectedMenu == null) {
            javax.swing.JOptionPane.showMessageDialog(null, "아이스크림 맛을 선택해주세요.");
            return;
        }

        mainFrame.changePanel(optionPanel);
    });

    // 옵션 화면에서 장바구니 화면으로 이동
    optionPanel.getNextBtn().addActionListener(e -> {
        mainFrame.changePanel(cartPanel);
    });
}
}
