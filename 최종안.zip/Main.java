public class Main {
    public static void main(String[] args) {

        // 전체 창 생성
        MainFrame mainFrame = new MainFrame();

        // View 객체 생성
        MainPanel mainPanel = new MainPanel();
        MenuPanel menuPanel = new MenuPanel();
        OptionPanel optionPanel = new OptionPanel();
        CartPanel cartPanel = new CartPanel();
        PaymentPanel paymentPanel = new PaymentPanel(); 
        OrderCompletePanel orderCompletePanel = new OrderCompletePanel();

        // Model 객체 생성
        Cart cart = new Cart();

        mainFrame.getMainPanel().add(mainPanel, "MainPanel");
        mainFrame.getMainPanel().add(menuPanel, "MenuPanel");
        mainFrame.getMainPanel().add(optionPanel, "OptionPanel");
        mainFrame.getMainPanel().add(cartPanel, "CartPanel");
        mainFrame.getMainPanel().add(paymentPanel, "PaymentPanel");
        mainFrame.getMainPanel().add(orderCompletePanel, "OrderCompletePanel");

        // Controller 객체 생성
        // View와 Model 객체를 Control에 넘겨 연결
        Control control = new Control(
                mainFrame,
                mainPanel,
                menuPanel,
                optionPanel,
                cartPanel,
                paymentPanel,
                orderCompletePanel,
                cart
        );

        // 처음 보여줄 화면 설정
        mainFrame.changePanel("MainPanel");

        // 화면 표시
        mainFrame.setVisible(true);
    }
}
