import javax.swing.*;
import java.awt.*;

public class PaymentPanel extends JPanel {
    private JLabel titleLabel;
    private JLabel totalPriceLabel;
    private JButton cashBtn;
    private JButton cardBtn;

    public PaymentPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(new Color(247, 250, 252));

        titleLabel = new JLabel("결제 수단을 선택하세요", SwingConstants.CENTER);
        titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);

        totalPriceLabel = new JLabel("총 결제 금액: 0원", SwingConstants.CENTER);
        totalPriceLabel.setFont(new Font("맑은 고딕", Font.BOLD, 22));
        totalPriceLabel.setForeground(new Color(43, 108, 176));
        add(totalPriceLabel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setOpaque(false);

        cashBtn = new JButton("현금 결제");
        cashBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        cashBtn.setBackground(new Color(72, 187, 120));
        cashBtn.setForeground(Color.WHITE);

        cardBtn = new JButton("카드 결제");
        cardBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        cardBtn.setBackground(new Color(43, 108, 176));
        cardBtn.setForeground(Color.WHITE);

        buttonPanel.add(cashBtn);
        buttonPanel.add(cardBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        cashBtn.setEnabled(false);
        cardBtn.setEnabled(false);
    }

    public JButton getCashBtn() { return cashBtn; }
    public JButton getCardBtn() { return cardBtn; }

    public void setTotalPrice(int price) {
        totalPriceLabel.setText("총 결제 금액: " + price + "원");
    }
}
