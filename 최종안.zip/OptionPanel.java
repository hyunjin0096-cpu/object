import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class OptionPanel extends JPanel {
    private JRadioButton cupRadio, coneRadio;
    private ButtonGroup servingGroup;
    private JCheckBox chocochipCheck, honeyCheck, cerealCheck;

    // 버튼 2개로 변경
    private JButton addMenuBtn;
    private JButton orderBtn;

    public OptionPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("옵션 및 토핑 추가", SwingConstants.CENTER);
        titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        add(titleLabel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // 용기 선택
        JPanel servingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        servingPanel.setBorder(BorderFactory.createTitledBorder("용기 선택 (Serving Option)"));

        cupRadio = new JRadioButton("컵 (cup) +0원", true);
        coneRadio = new JRadioButton("콘 (cone) +500원");

        servingGroup = new ButtonGroup();
        servingGroup.add(cupRadio);
        servingGroup.add(coneRadio);

        servingPanel.add(cupRadio);
        servingPanel.add(coneRadio);

        // 토핑 선택
        JPanel toppingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        toppingPanel.setBorder(BorderFactory.createTitledBorder("토핑 추가 (Topping Option)"));

        chocochipCheck = new JCheckBox("초코칩 (chocochip) +1,000원");
        honeyCheck = new JCheckBox("꿀 (honey) +500원");
        cerealCheck = new JCheckBox("시리얼 (cereal) +1,000원");

        toppingPanel.add(chocochipCheck);
        toppingPanel.add(honeyCheck);
        toppingPanel.add(cerealCheck);

        centerPanel.add(servingPanel);
        centerPanel.add(Box.createVerticalStrut(15));
        centerPanel.add(toppingPanel);
        add(centerPanel, BorderLayout.CENTER);

        // 하단 버튼 영역
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));

        addMenuBtn = new JButton("메뉴 추가");
        addMenuBtn.setBackground(new Color(72, 187, 120));
        addMenuBtn.setForeground(Color.WHITE);
        addMenuBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));

        orderBtn = new JButton("주문하기");
        orderBtn.setBackground(new Color(43, 108, 176));
        orderBtn.setForeground(Color.WHITE);
        orderBtn.setFont(new Font("맑은 고딕", Font.BOLD, 14));

        buttonPanel.add(addMenuBtn);
        buttonPanel.add(orderBtn);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    public JRadioButton getCupRadio() { return cupRadio; }
    public JRadioButton getConeRadio() { return coneRadio; }

    public JCheckBox getChocochipCheck() { return chocochipCheck; }
    public JCheckBox getHoneyCheck() { return honeyCheck; }
    public JCheckBox getCerealCheck() { return cerealCheck; }

    // 메뉴 추가 버튼
    public JButton getAddMenuBtn() {
        return addMenuBtn;
    }

    // 주문하기 버튼
    public JButton getOrderBtn() {
        return orderBtn;
    }

    // 기존 코드와 충돌 방지용
    public JButton getNextBtn() {
        return orderBtn;
    }

    public String getSelectedContainer() {
        if (cupRadio.isSelected()) {
            return "cup";
        } else if (coneRadio.isSelected()) {
            return "cone";
        }
        return "cup";
    }

    public ArrayList<String> getSelectedToppings() {
        ArrayList<String> toppings = new ArrayList<>();

        if (chocochipCheck.isSelected()) toppings.add("chocochip");
        if (honeyCheck.isSelected()) toppings.add("honey");
        if (cerealCheck.isSelected()) toppings.add("cereal");

        return toppings;
    }

    // 메뉴 추가 후 옵션 화면 초기화용
    public void resetOptions() {
        cupRadio.setSelected(true);
        chocochipCheck.setSelected(false);
        honeyCheck.setSelected(false);
        cerealCheck.setSelected(false);
    }
}