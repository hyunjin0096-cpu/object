public class Main {
    public static void main(String[] args) {

        // 전체 창 생성
        MainFrame mainFrame = new MainFrame();

        // View 객체 생성
        MainPanel mainPanel = new MainPanel();
        MenuPanel menuPanel = new MenuPanel();
        OptionPanel optionPanel = new OptionPanel();
        CartPanel cartPanel = new CartPanel();
        OrderCompletePanel orderCompletePanel = new OrderCompletePanel();

        // Model 객체 생성
        Cart cart = new Cart();

        // Controller 객체 생성
        // View와 Model 객체를 Control에 넘겨 연결
        Control control = new Control(
                mainFrame,
                mainPanel,
                menuPanel,
                optionPanel,
                cartPanel,
                orderCompletePanel,
                cart
        );

        // 처음 보여줄 화면 설정
        mainFrame.changePanel(mainPanel);

        // 화면 표시
        mainFrame.setVisible(true);
    }
}
