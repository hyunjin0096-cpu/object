import javax.swing.JOptionPane;

public class Control {

    private MainFrame mainFrame;
    private MainPanel mainPanel;
    private MenuPanel menuPanel;
    private OptionPanel optionPanel;
    private CartPanel cartPanel;
    private OrderCompletePanel orderCompletePanel;

    private Cart cart;
    private Menu selectedMenu;

    public Control(
            MainFrame mainFrame,
            MainPanel mainPanel,
            MenuPanel menuPanel,
            OptionPanel optionPanel,
            CartPanel cartPanel,
            OrderCompletePanel orderCompletePanel,
            Cart cart
    ) {
        this.mainFrame = mainFrame;
        this.mainPanel = mainPanel;
        this.menuPanel = menuPanel;
        this.optionPanel = optionPanel;
        this.cartPanel = cartPanel;
        this.orderCompletePanel = orderCompletePanel;
        this.cart = cart;

        connectEvents();
    }

    private void connectEvents() {

        // 시작 화면 → 메뉴 선택 화면
        mainPanel.getNextBtn().addActionListener(e -> {
            mainFrame.changePanel(menuPanel);
        });

        // 메뉴 선택
        menuPanel.getChocoRadio().addActionListener(e -> {
            selectedMenu = new Menu("choco", 3500);
        });

        menuPanel.getVanillaRadio().addActionListener(e -> {
            selectedMenu = new Menu("vanilla", 3500);
        });

        menuPanel.getStrawberryRadio().addActionListener(e -> {
            selectedMenu = new Menu("strawberry", 3500);
        });

        // 메뉴 선택 화면 → 옵션 화면
        menuPanel.getNextBtn().addActionListener(e -> {
            if (selectedMenu == null) {
                selectedMenu = new Menu(menuPanel.getSelectedFlavor(), 3500);
            }

            mainFrame.changePanel(optionPanel);
        });

        // 옵션 화면 → 메뉴 추가
        // 현재 선택한 메뉴와 옵션을 장바구니에 담고 다시 메뉴 선택 화면으로 이동
        optionPanel.getAddMenuBtn().addActionListener(e -> {
            addCurrentOrderToCart();

            optionPanel.resetOptions();
            selectedMenu = null;

            mainFrame.changePanel(menuPanel);
        });

        // 옵션 화면 → 주문하기
        // 현재 선택한 메뉴와 옵션을 장바구니에 담고 장바구니 화면으로 이동
        optionPanel.getOrderBtn().addActionListener(e -> {
            addCurrentOrderToCart();
            refreshCartPanel();

            optionPanel.resetOptions();
            selectedMenu = null;

            mainFrame.changePanel(cartPanel);
        });

        // 장바구니 화면 → 주문 완료 화면
        cartPanel.getNextBtn().addActionListener(e -> {
            if (cart.isEmpty()) {
                JOptionPane.showMessageDialog(null, "장바구니가 비어 있습니다.");
                return;
            }

            orderCompletePanel.setOrderNumber("0028");
            mainFrame.changePanel(orderCompletePanel);
        });

        // 주문 완료 화면 → 처음 화면
        orderCompletePanel.getNextBtn().addActionListener(e -> {
            cart.clear();
            selectedMenu = null;
            refreshCartPanel();

            mainFrame.changePanel(mainPanel);
        });
    }

    // 현재 선택된 메뉴와 옵션을 장바구니에 추가
    private void addCurrentOrderToCart() {
        if (selectedMenu == null) {
            selectedMenu = new Menu(menuPanel.getSelectedFlavor(), 3500);
        }

        ServingOption servingOption;

        if (optionPanel.getConeRadio().isSelected()) {
            servingOption = new ServingOption(ServingOption.Type.CONE);
        } else {
            servingOption = new ServingOption(ServingOption.Type.CUP);
        }

        OrderItem orderItem = new OrderItem(selectedMenu, servingOption);

        if (optionPanel.getChocochipCheck().isSelected()) {
            orderItem.addTopping(new ToppingOption(ToppingOption.Type.CHOCOCHIP));
        }

        if (optionPanel.getHoneyCheck().isSelected()) {
            orderItem.addTopping(new ToppingOption(ToppingOption.Type.HONEY));
        }

        if (optionPanel.getCerealCheck().isSelected()) {
            orderItem.addTopping(new ToppingOption(ToppingOption.Type.CEREAL));
        }

        cart.addItem(orderItem);
    }

    // 장바구니 화면 갱신
    private void refreshCartPanel() {
        cartPanel.getTableModel().setRowCount(0);

        for (OrderItem item : cart.getCartItems()) {
            cartPanel.addOrderToTable(
                    item.getMenuName(),
                    item.getServingOption().getOptionName(),
                    item.toppingsSummary(),
                    item.getTotalPrice()
            );
        }

        cartPanel.setTotalPrice(cart.getTotalPrice());
    }
}
